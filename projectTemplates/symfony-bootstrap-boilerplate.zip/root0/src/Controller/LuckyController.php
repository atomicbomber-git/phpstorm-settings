<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;

class LuckyController extends AbstractController
{
    public function index()
    {
        return $this->render("lucky/index.html.twig");
    }
}<IntelliJ_File_Header>